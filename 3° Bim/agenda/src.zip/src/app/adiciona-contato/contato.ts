export class Contato {
    private nome: string;
    private telefone: number;
    private email: string;
    private aniversario: string;
    private tipo: string;
    private favorito: boolean = false;

    constructor(nm: string, tel: number, email: string, niver: string, tp: string, fav: boolean){
        this.nome = nm;
        this.telefone = tel;
        this.email = email;
        this.aniversario = niver;
        this.tipo = tp;
        this.favorito = fav;
    }

    alterarnome(nm: string) {
        this.nome = nm;
    }

    obternome(): string {
        return this.nome;
    }

    alterartelefone(tel: number) {
        this.telefone = tel;
    }

    obtertelefone(): number {
        return this.telefone;
    }

    alteraremail(email: string) {
        this.email = email;
    }

    obteremail(): string {
        return this.email;
    }

    alteraraniversario(niver: string) {
        this.aniversario = niver;
    }

    obteraniversario(): string {
        return this.aniversario;
    }

    alterartipo(tp: string){
        this.tipo = tp;
    }

    obtertipo(): string {
        return this.tipo;
    }

    alterarfavorito(value: boolean){
        this.favorito = value;
    }

    obterfav(): boolean {
        return this.favorito;
    }
}