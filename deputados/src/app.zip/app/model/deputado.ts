export class Deputado {
    nome: string = ''
    siglaPartido: string = ''
    siglaUf: string = ''
    urlFoto: string  = ''
}